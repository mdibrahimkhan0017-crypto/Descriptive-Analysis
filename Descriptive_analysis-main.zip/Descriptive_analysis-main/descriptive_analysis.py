import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("Dataset .csv")

numerical_cols = df.select_dtypes(include=np.number)
print("\nNumerical Statistics:")
print(numerical_cols.describe())

summary = pd.DataFrame({
    "Mean": numerical_cols.mean(),
    "Median": numerical_cols.median(),
    "Standard Deviation": numerical_cols.std()
})

print("\nSummary Statistics:")
print(summary)

# Categorical distributions
print("\nTop Country Codes:")
print(df['Country Code'].value_counts().head(10))

print("\nTop Cities:")
print(df['City'].value_counts().head(10))

print("\nTop Cuisines:")
print(df['Cuisines'].value_counts().head(10))

# Plot top cities
top_cities = df['City'].value_counts().head(10)
plt.figure(figsize=(8,5))
sns.barplot(x=top_cities.values, y=top_cities.index)
plt.title("Top 10 Cities with Highest Number of Restaurants")
plt.show()

# Plot top cuisines
top_cuisines = df['Cuisines'].value_counts().head(10)
plt.figure(figsize=(8,5))
sns.barplot(x=top_cuisines.values, y=top_cuisines.index)
plt.title("Top 10 Cuisines")
plt.show()